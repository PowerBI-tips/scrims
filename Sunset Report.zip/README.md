Welcome to Power BI Desktop Projects 


tips+ 

============================================

Steps to open the project:
    1) Unzip the folder
    2) Enable the new feature on Power BI - https://learn.microsoft.com/en-us/power-bi/developer/projects/projects-overview#enable-preview-features
    3) Find the file named "<YOUR_Sunset Report>.pbip" and open it using Microsoft Power BI Desktop

For more information on PBIP files, please visit: https://learn.microsoft.com/en-us/power-bi/developer/projects/projects-overview
    

